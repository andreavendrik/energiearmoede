<?php wp_footer(); ?>

    <div class="footer">
      <p>De <span>energie armoede toolkit</span> is mede mogelijk gemaakt door </p>
    </div>

  </div>
</body>
</html>
